﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Задача_18
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int dota = 0;

            if (comboBox1.SelectedIndex == 0)
            { dota = 10; }
            if (comboBox1.SelectedIndex == 1)
            { dota = 20; }
            if (comboBox1.SelectedIndex == 2)
            { dota = 30; }

            string dota1 = textBox1.Text;

            int dota2 = Convert.ToInt32(dota1);

            int itog = dota2 * 200 + dota;

            label4.Text = Convert.ToString(itog);
        }
    }
}
