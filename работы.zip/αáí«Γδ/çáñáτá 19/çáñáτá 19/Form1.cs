﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Задача_19
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string vys = textBox1;
            string shir = textBox2;

            int s = Convert.ToInt32(vys) * Convert.ToInt32(shir);
            int dota = 0;

            if (comboBox1.SelectedIndex == 0)
            { dota = 3500; }
            if (comboBox1.SelectedIndex == 1)
            { dota = 2500; }
            if (checkBox1.Checked == true)
            { dota = dota + 100; }
            if (checkBox2.Checked == true)
            { dota = dota + 200; }
            if (checkBox3.Checked == true)
            { dota = dota + 300; }

            int itog = s * 7 + dota;
            label4.Text = Convert.ToString(itog);
        }
    }
}
