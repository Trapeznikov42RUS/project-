﻿
namespace vagonimln
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.kolvoBox = new System.Windows.Forms.TextBox();
            this.mestoPetra = new System.Windows.Forms.TextBox();
            this.mestoVasi = new System.Windows.Forms.TextBox();
            this.nomerPetra = new System.Windows.Forms.TextBox();
            this.nomerVasi = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.xLabel = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(23, 109);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(160, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Введите кол-во мест в вагоне";
            // 
            // kolvoBox
            // 
            this.kolvoBox.Location = new System.Drawing.Point(189, 106);
            this.kolvoBox.Name = "kolvoBox";
            this.kolvoBox.Size = new System.Drawing.Size(100, 20);
            this.kolvoBox.TabIndex = 1;
            // 
            // mestoPetra
            // 
            this.mestoPetra.Location = new System.Drawing.Point(189, 147);
            this.mestoPetra.Name = "mestoPetra";
            this.mestoPetra.Size = new System.Drawing.Size(100, 20);
            this.mestoPetra.TabIndex = 2;
            // 
            // mestoVasi
            // 
            this.mestoVasi.Location = new System.Drawing.Point(189, 184);
            this.mestoVasi.Name = "mestoVasi";
            this.mestoVasi.Size = new System.Drawing.Size(100, 20);
            this.mestoVasi.TabIndex = 3;
            // 
            // nomerPetra
            // 
            this.nomerPetra.Location = new System.Drawing.Point(509, 280);
            this.nomerPetra.Name = "nomerPetra";
            this.nomerPetra.Size = new System.Drawing.Size(100, 20);
            this.nomerPetra.TabIndex = 4;
            // 
            // nomerVasi
            // 
            this.nomerVasi.Location = new System.Drawing.Point(645, 99);
            this.nomerVasi.Name = "nomerVasi";
            this.nomerVasi.Size = new System.Drawing.Size(100, 20);
            this.nomerVasi.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(23, 150);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(117, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Введите место Петра";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(23, 187);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(129, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Введите место Василия";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(642, 73);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(113, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Номер вагона Петра";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(502, 255);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(125, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Номер вагона Василия";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(536, 357);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 10;
            this.button1.Text = "Вычислить";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(352, 395);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(238, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "Василий должен пройти до встречи с Петром";
            // 
            // xLabel
            // 
            this.xLabel.AutoSize = true;
            this.xLabel.Location = new System.Drawing.Point(594, 395);
            this.xLabel.Name = "xLabel";
            this.xLabel.Size = new System.Drawing.Size(12, 13);
            this.xLabel.TabIndex = 12;
            this.xLabel.Text = "x";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(612, 395);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(48, 13);
            this.label8.TabIndex = 13;
            this.label8.Text = "вагонов";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.xLabel);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.nomerVasi);
            this.Controls.Add(this.nomerPetra);
            this.Controls.Add(this.mestoVasi);
            this.Controls.Add(this.mestoPetra);
            this.Controls.Add(this.kolvoBox);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox kolvoBox;
        private System.Windows.Forms.TextBox mestoPetra;
        private System.Windows.Forms.TextBox mestoVasi;
        private System.Windows.Forms.TextBox nomerPetra;
        private System.Windows.Forms.TextBox nomerVasi;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label xLabel;
        private System.Windows.Forms.Label label8;
    }
}

