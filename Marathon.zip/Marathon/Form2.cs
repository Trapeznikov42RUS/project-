﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KorolevMarathon
{
    public partial class Form2 : Form
    {
        float gen;
        public Form2()
        {
            InitializeComponent();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            gen = 66;
            label22.Text = gen.ToString();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            gen = 655;
            label22.Text = gen.ToString();
        }

        private void label22_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            gen = 0;
            rost.Clear();
            ves.Clear();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            float v = float.Parse(ves.Text);
            float r = float.Parse(rost.Text);
            float f = v/(r/100);
            label9.Text = f.ToString();
        }
    }
}
