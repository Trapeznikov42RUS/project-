﻿using KorolevMarathon;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Marathon
{
    public partial class Form1 : Form
    {
        float gen;
        float vs;
        float ro;
        float age;
        public Form1()
        {
            InitializeComponent();

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            gen = 655;
            vs = 9.6f;
            ro = 1.8f;
            age = 4.7f;
            label9.Text = gen.ToString();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            gen = 66;
            vs = 13.7f;
            ro = 5;
            age = 6.8f;
            label9.Text = gen.ToString();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            gen = 0;
            rost.Clear();
            ag.Clear();
            ves.Clear();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            float v = float.Parse(ves.Text);
            float r = float.Parse(rost.Text);
            float a = float.Parse(ag.Text);
            float f = gen + (vs * v) + (ro * r) - (age * a);
            float f1 = Convert.ToInt32(f * 1.2);
            float f2 = Convert.ToInt32(f * 1.375);
            float f3 = Convert.ToInt32(f * 1.55);
            float f4 = Convert.ToInt32(f * 1.725);
            float f5 = Convert.ToInt32(f * 1.9);
            label9.Text = f.ToString();
            label16.Text = f1.ToString();
            label17.Text = f2.ToString();
            label19.Text = f3.ToString();
            label20.Text = f4.ToString();
            label21.Text = f5.ToString();
        }

        private void label16_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click_1(object sender, EventArgs e)
        {
            gen = 66;
            vs = 13.7f;
            ro = 5;
            age = 6.8f;
            label22.Text = gen.ToString();
        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {
            gen = 655;
            vs = 9.6f;
            ro = 1.8f;
            age = 4.7f;
            label22.Text = gen.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 frm = new Form2();
            frm.Show();
            Close();
        }
    }
}
